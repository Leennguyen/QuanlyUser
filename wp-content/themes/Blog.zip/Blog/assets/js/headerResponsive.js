function show() {
    document.getElementById("nav_reponsive").style.display ="block";
    document.getElementById("header_baricon").style.display ="none";
   
    document.getElementById("nav_reponsive").style.animation ="mymoveleft 2s";
}
function hide() {
    document.getElementById("header_baricon").style.display ="block";
    
   

        document.getElementById("nav_reponsive").style.display = "none"
  
}