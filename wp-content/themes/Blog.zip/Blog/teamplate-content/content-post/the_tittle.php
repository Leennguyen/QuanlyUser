<div class="post-tittle">
    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
        <h1>
            <?php echo the_title()?>< /h1>
    </article>
</div>